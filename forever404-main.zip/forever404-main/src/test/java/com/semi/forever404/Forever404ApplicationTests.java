package com.semi.forever404;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Forever404ApplicationTests {

	@Test
	void contextLoads() {
	}

}
