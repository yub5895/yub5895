package com.server.mbti;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MbtiApplicationTests {

	@Test
	void contextLoads() {
	}

}
